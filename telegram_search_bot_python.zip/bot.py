import telebot
from telebot import types
import json
import re

# --- CONFIGURATION ---
BOT_TOKEN = "8494458872:AAEHsvXeWECqaCWVezfZta-ix0urZrUlAzM"
CONTACTS_FILE = "contacts.json"

# --- DATA LOADING ---
try:
    with open(CONTACTS_FILE, "r", encoding="utf-8") as f:
        contacts = json.load(f)
except FileNotFoundError:
    print(f"Error: {CONTACTS_FILE} not found.")
    contacts = []

bot = telebot.TeleBot(BOT_TOKEN)

# --- HELPER FUNCTIONS ---
def search_contacts(query):
    results = []
    query = query.lower()
    
    for contact in contacts:
        name = contact.get("name", "").lower()
        position = contact.get("position", "").lower()
        phone = contact.get("phone", "")
        
        if query in name or query in position or query in phone:
            results.append(contact)
    return results

# --- MESSAGE HANDLERS ---
@bot.message_handler(commands=["start"])
def send_welcome(message):
    bot.reply_to(message, "سلام! خوش آمدید.\nبرای جستجو، نام، فامیلی، سمت یا شماره تلفن را وارد کنید.\nهمچنین می‌توانید از قابلیت Inline (تایپ یوزرنیم ربات در هر چتی) استفاده کنید.")

@bot.message_handler(func=lambda message: True)
def handle_message(message):
    text = message.text.strip()
    results = search_contacts(text)
    
    if not results:
        bot.reply_to(message, "موردی یافت نشد. لطفا عبارت دیگری را امتحان کنید.")
    else:
        response_text = f"🔍 نتایج جستجو برای: {text}\n\n"
        
        if len(results) > 10:
            response_text += f"تعداد نتایج زیاد است ({len(results)} مورد). لطفاً دقیق‌تر جستجو کنید.\n\n"
            results = results[:10] # Limit to 10 results for regular messages
            
        for contact in results:
            response_text += f"👤 {contact.get("name", "نامشخص")}\n"
            if contact.get("position"):
                response_text += f"🏢 {contact.get("position", "")}\n"
            response_text += f"📞 {contact.get("phone", "نامشخص")}\n"
            response_text += "------------------------\n"
            
        bot.reply_to(message, response_text)

# --- INLINE HANDLERS ---
@bot.inline_handler(lambda query: True)
def inline_query(inline_query):
    query_text = inline_query.query.strip()
    if not query_text:
        return
    
    results = search_contacts(query_text)
    inline_results = []
    
    for i, contact in enumerate(results):
        if i >= 50: # Telegram inline query limit
            break
        
        name = contact.get("name", "نامشخص")
        position = contact.get("position", "")
        phone = contact.get("phone", "نامشخص")
        
        description = f"{position} | {phone}" if position else phone
        
        item = types.InlineQueryResultArticle(
            id=str(i), # Unique ID for each result
            title=name,
            input_message_content=types.InputTextMessageContent(
                message_text=f"👤 {name}\n🏢 {position or "نامشخص"}\n📞 {phone}"
            ),
            description=description
        )
        inline_results.append(item)
        
    bot.answer_inline_query(inline_query.id, inline_results)

# --- START BOT ---
print("Bot started...")
bot.polling(none_stop=True)
